//
//  ViewController.swift
//  Lights_Out
//
//  Created by VAMPSTAR's on 04/02/18.
//  Copyright © 2018 VAMPSTAR's. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func LightoutTap(_ sender: Any) {
        self.view.backgroundColor = UIColor.black
    }
    
    @IBAction func LightinTap(_ sender: Any) {
        self.view.backgroundColor = UIColor.yellow
    }
    

}

